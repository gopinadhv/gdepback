import React from "react";
import PropTypes from "prop-types";
import axios from "axios";
import { fromJS } from 'immutable';
import Form from "../../Parts/Form";
import FloatingPanel from "../../Panel/EditPanel";
import GlobalVariable from "../../../../path/global";

const baseApiUrl = GlobalVariable.BASE_API_URL;
class AlertEditCrud extends React.Component {
  sendValues = values => {
    // console.log(values);
    setTimeout(() => {
      const userDetails = JSON.parse(localStorage.getItem("userDetails"));
      let obj = JSON.stringify(values);
      let bodyParameters = JSON.parse(obj);
      var config = {
        headers: { Authorization: userDetails.token }
      };
      var object = bodyParameters;
      // console.log(object);

      if (object.id) {
        axios
          .put(baseApiUrl + "v1/alert/" + object.id, object, config)
          .then(response => {
            window.location.href = '/app/alert';
         this.props.submit(fromJS(response.data), this.props.branch);
          })
          .catch(error => {
            if(error.response){
              alert("Token Expired");
            } 
          });
      }
    }, 500);
  };

  render() {
    const {
      editForm,
      closeForm,
      children,
      branch,
      initValues,
      formTitle,
    } = this.props;
    return (
      <div>
        <FloatingPanel
          editForm={editForm}
          branch={branch}
          closeForm={closeForm}
          formTitle={formTitle} 
          tableName="Employee"
        >
          <Form
            onSubmit={this.sendValues}
            initValues={initValues}
            branch={branch}
          >
            {children}
          </Form>
        </FloatingPanel>
      </div>
    );
  }
}

AlertEditCrud.propTypes = {
  editForm: PropTypes.bool.isRequired,
  closeForm: PropTypes.func.isRequired,
  children: PropTypes.node.isRequired,
	branch: PropTypes.string.isRequired,
	initValues: PropTypes.object.isRequired,
  formTitle: PropTypes.string.isRequired,
};

export default AlertEditCrud;
