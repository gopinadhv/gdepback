import React, { Component, Fragment } from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import 'dan-styles/vendors/select/select.css';
import { Field } from "redux-form/immutable";
// import MenuItem from "@material-ui/core/MenuItem";
// import InputLabel from "@material-ui/core/InputLabel";
// import FormControl from "@material-ui/core/FormControl";
import { connect } from "react-redux";
import axios from "axios";
import { bindActionCreators } from "redux";
import { TextField } from "redux-form-material-ui";
import {
  fetchAction,
  fetchInactiveAction,
  addAction,
  closeAction,
  submitAction,
  removeAction,
  editAction,
  closeNotifAction
} from "dan-actions/CrudTbFrmActions";
import CrudTableForm from "./AlertCrud";
import AlertCrudForm from "./AlertEditCrud";
import headers from "./Headers";
import Notification from "../../Notification/Notification";
import GlobalVariable from "../../../../path/global";

const branch = "crudTbFrmDemo";
const baseApiUrl = GlobalVariable.BASE_API_URL;

// validation functions
const required = value => (value == null ? "Required" : undefined);
// const email = value =>
//   value && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value)
//     ? "Invalid email"
//     : undefined;

const styles = theme => ({
  root: {
    flexGrow: 1
  },
  field: {
    width: "100%",
    marginBottom: 15
  },
  container: {
    display: "grid",
    gridTemplateColumns: "repeat(12, 1fr)",
    gridGap: `${theme.spacing.unit * 3}px`
  },
  chip: {
    margin: theme.spacing.unit / 4,
  },
  formControl: {
    width: '100%',
    margin: '20px 0'
  }
});

// const trueBool = true;
var loader = false;
var rows = [];
var InactiveRows = [];



class Alert extends Component {
  constructor(props){
    super(props);
    this.state = {
      selected: [],
      filterText: '',
      page: 0,
      rowsPerPage: 10,
      defaultPerPage: 10,
      order: 'asc',
      orderBy: 'alertName',
    };
  }
  
  componentDidMount() {
    this.handledata();
  }
  
  // componentWillReceiveProps(nextProp){
  //   this.handledata();
  // }
  
  handledata(){
    const userDetails = JSON.parse(localStorage.getItem("userDetails"));
    axios
      .get(baseApiUrl + "v1/alert", {
        headers: { Authorization: userDetails.token }
      })
      .then(response => {
        var activeData = response.data.activeData;
        var inactiveData = response.data.inactiveData;
          if(activeData === undefined){
            rows = [];  
          }else{
            rows = activeData;
          }
          
          if(inactiveData === undefined){
            InactiveRows = [];  
          }else{
            InactiveRows = inactiveData;
          }
        loader = true;
      })
      .catch(error => {
        console.log("Error fetching and parsing data", error);
      });
  }
  handleClickShowPassword = () => {
    this.setState({ showPassword: !this.state.showPassword });
  };

  handleMouseDownPassword = event => {
    event.preventDefault();
  };

  saveRef = ref => {
    this.ref = ref;
    return this.ref;
  };

  render() {
    const {
      classes,
      fetchData,
      fetchInactiveData,
      addNew,
      closeForm,
      submit,
      removeRow,
      editRow,
      dataTable,
      dataInActiveTable,
      openForm,
      initValues,
      closeNotif,
      messageNotif,
      title,
      editForm,
    } = this.props;
     
    const {
      selected,
      filterText,
      page,
      rowsPerPage,
      defaultPerPage,
      order,
      orderBy,
    } = this.state;
    
    if(initValues){
      var init = JSON.stringify(initValues);
      var editValue = JSON.parse(init);
    }

    return (
      <Fragment>
        {loader === true ? (
          <div>
            <Notification
              close={() => closeNotif(branch)}
              message={messageNotif}
            />
            <div className={classes.rootTable}>
              <CrudTableForm
                dataTable={dataTable}
                dataInActiveTable={dataInActiveTable}
                openForm={openForm}
                dataInit={rows}
                InactiveRows={InactiveRows}
                anchor={headers}
                title=""
                fetchData={fetchData}
                fetchInactiveData={fetchInactiveData}
                addNew={addNew}
                closeForm={closeForm}
                submit={submit}
                removeRow={removeRow}
                editRow={editRow}
                branch={branch}
                initValues={initValues}
                selected={selected}
                filterText={filterText}
                page={page}
                defaultPerPage={defaultPerPage}
                rowsPerPage={rowsPerPage}
                order={order}
                orderBy={orderBy}
                formTitle={title}
              >
                {/* Create Your own form, then arrange or custom it as You like */}

                <Grid container spacing={24}>
                  <Grid item xs={4} style={{padding:"0px 12px"}}>
                    <div>
                      <Field
                        name="alertName"
                        component={TextField}
                        placeholder="alertName"
                        label="alertName"
                        validate={required}
                        required
                        ref={this.saveRef}
                        withRef
                        className={classes.field}
                        autoComplete='off'
                      />
                    </div>
                  </Grid>
                  <Grid item xs={4} style={{padding:"0px 12px"}}>
                    <div>
                    <Field
                        name="alertCode"
                        component={TextField}
                        placeholder="alertCode"
                        label="alertCode"
                        validate={required}
                        required
                        ref={this.saveRef}
                        withRef
                        className={classes.field}
                        autoComplete='off'
                      />
                    </div>
                  </Grid>
                  <Grid item xs={4} style={{padding:"0px 12px"}}>
                    <div>
                      <Field
                        name="alertsTo"
                        component={TextField}
                        placeholder="alertsTo"
                        label="alertsTo"
                        validate={required}
                        required
                        ref={this.saveRef}
                        withRef
                        className={classes.field}
                        autoComplete='off'
                      />
                    </div>
                  </Grid>
                </Grid>
                <Grid container spacing={24}>
                <Grid item xs={8} style={{padding:"0px 12px"}}>
                    <div>
                      <Field
                        name="description"
                        component={TextField}
                        placeholder="description"
                        label="description"
                        validate={required}
                        required
                        ref={this.saveRef}
                        withRef
                        className={classes.field}
                        autoComplete='off'
                      />
                    </div>
                  </Grid>
                </Grid>
                                  

                {/* No need create button or submit, because that already made in this component */}
              </CrudTableForm>

              <AlertCrudForm
								editForm={editForm}
								closeForm={closeForm}
								branch={branch}
								initValues={initValues}
                formTitle={title}
							>

								{/* Create Your own form, then arrange or custom it as You like */}
								{editValue ? (
									<Fragment>
                    <Grid container spacing={24}>
                      <Grid item xs={4} style={{padding:"0px 12px"}}>
                        <div>
                          <Field
                            name="alertName"
                            component={TextField}
                            placeholder="alertName"
                            label="alertName"
                            validate={required}
                            required
                            ref={this.saveRef}
                            withRef
                            className={classes.field}
                            autoComplete='off'
                          />
                        </div>
                      </Grid>
                      <Grid item xs={4} style={{padding:"0px 12px"}}>
                        <div>
                        <Field
                            name="alertCode"
                            component={TextField}
                            placeholder="alertCode"
                            label="alertCode"
                            validate={required}
                            required
                            ref={this.saveRef}
                            withRef
                            className={classes.field}
                            autoComplete='off'
                          />
                        </div>
                      </Grid>
                      <Grid item xs={4} style={{padding:"0px 12px"}}>
                        <div>
                          <Field
                            name="alertsTo"
                            component={TextField}
                            placeholder="alertsTo"
                            label="alertsTo"
                            validate={required}
                            required
                            ref={this.saveRef}
                            withRef
                            className={classes.field}
                            autoComplete='off'
                          />
                        </div>
                      </Grid>
                    </Grid>
                    <Grid container spacing={24}>
                    <Grid item xs={8} style={{padding:"0px 12px"}}>
                        <div>
                          <Field
                            name="description"
                            component={TextField}
                            placeholder="description"
                            label="description"
                            validate={required}
                            required
                            ref={this.saveRef}
                            withRef
                            className={classes.field}
                            autoComplete='off'
                          />
                        </div>
                      </Grid>
                    </Grid>

									</Fragment>
								) : (
										<Fragment />
									)}

								{/* No need create button or submit, because that already made in this component */}
							</AlertCrudForm>

            </div>
          </div>
        ) : (
          <Fragment />
        )}
      </Fragment>
    );
  }
}

Alert.propTypes = {
  dataTable: PropTypes.object.isRequired,
  dataInActiveTable: PropTypes.object.isRequired,
  openForm: PropTypes.bool.isRequired,
  editForm: PropTypes.bool.isRequired,
  classes: PropTypes.object.isRequired,
  fetchData: PropTypes.func.isRequired,
  fetchInactiveData: PropTypes.func.isRequired,
  addNew: PropTypes.func.isRequired,
  closeForm: PropTypes.func.isRequired,
  submit: PropTypes.func.isRequired,
  removeRow: PropTypes.func.isRequired,
  editRow: PropTypes.func.isRequired,
  initValues: PropTypes.object.isRequired,
  closeNotif: PropTypes.func.isRequired,
  messageNotif: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
};

const mapStateToProps = state => ({
  force: state, // force state from reducer
  initValues: state.getIn([branch, "formValues"]),
  dataTable: state.getIn([branch, "dataTable"]),
  dataInActiveTable: state.getIn([branch, 'dataInActiveTable']),
  title: state.getIn([branch, 'title']),
  openForm: state.getIn([branch, "showFrm"]),
  editForm: state.getIn([branch, "editFrm"]),
  messageNotif: state.getIn([branch, "notifMsg"]),
});

const mapDispatchToProps = dispatch => ({
  fetchData: bindActionCreators(fetchAction, dispatch),
  fetchInactiveData: bindActionCreators(fetchInactiveAction, dispatch),
  addNew: bindActionCreators(addAction, dispatch),
  closeForm: bindActionCreators(closeAction, dispatch),
  submit: bindActionCreators(submitAction, dispatch),
  removeRow: bindActionCreators(removeAction, dispatch),
  editRow: bindActionCreators(editAction, dispatch),
  closeNotif: bindActionCreators(closeNotifAction, dispatch)
});

const CrudTbFormDemoMapped = connect(
  mapStateToProps,
  mapDispatchToProps
)(Alert);

export default withStyles(styles)(CrudTbFormDemoMapped);
