import React, { Fragment } from 'react';
// import CsvDownloader from 'react-csv-downloader';
import ReactToPrint from "react-to-print";
import Print from '@material-ui/icons/Print';
// import axios from "axios";
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
// import CloudDownload from '@material-ui/icons/CloudDownload';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import AddIcon from '@material-ui/icons/Add';
import Button from '@material-ui/core/Button';
import isWidthUp from '@material-ui/core/withWidth';
import Tooltip from '@material-ui/core/Tooltip';
import DeleteIcon from '@material-ui/icons/Delete';
import ArchiveIcon from '@material-ui/icons/Archive';
import BookmarkIcon from '@material-ui/icons/Bookmark';
import FilterListIcon from '@material-ui/icons/FilterList';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import SearchIcon from '@material-ui/icons/Search';
import FormControl from '@material-ui/core/FormControl';
import Input from '@material-ui/core/Input';
import css from 'dan-styles/Table.scss';
import InputAdornment from '@material-ui/core/InputAdornment';
import styles from '../../Parts/tableStyle-jss';
import AlertPrint from './AlertPrint';
// import GlobalVariable from "../../../../path/global";

// const baseApiUrl = GlobalVariable.BASE_API_URL;
// const columns = [
//   {id: 'id',displayName: 'Id'}, 
//   {id: 'branchName', displayName: 'Branch Name'},
//   {id: 'branchCode', displayName: 'Branch Name'},
//   {id: 'branchEmail', displayName: 'Branch Email'},
//   {id: 'branchPhone', displayName: 'Branch Phone'},
//   {id: 'branchAddress', displayName: 'Branch Address'},
//   {id: 'branchCity', displayName: 'Branch City'},
//   {id: 'branchCountryId', displayName: 'Country'},
//   {id: 'branchStateId', displayName: 'State'},
//   {id: 'branchPincode', displayName: 'Pincode'},
//   {id: 'branchContactPerson', displayName: 'Branch Contact Person'},
//   {id: 'branchContactPhone', displayName: 'Branch Contact Phone'},
//   {id: 'status', displayName: 'Status'},
//   {id: 'createdBy', displayName: 'Created User'},
//   {id: 'updatedBy', displayName: 'Updated User'},
//   {id: 'createdAt', displayName: 'Created Date'},
//   {id: 'updatedAt', displayName: 'Updated date'},
// ];

class TableToolbar extends React.Component {
  state = {
    showSearch: false,
    // datas: []
  }

  // componentDidMount() {
  //   const userDetails = JSON.parse(localStorage.getItem("userDetails"));
  //   axios.get(baseApiUrl + 'v1/exportBranch', { headers: { "Authorization": userDetails.token } })
  //     .then(response => {
  //       var branches = response.data.branches;
  //       // console.log(branches);
  //       var colData = [];
  //       for (let i = 0; i < branches.length; i++) {
  //         var object = {};
  //         for(let key in branches[i]){
  //           if(key === 'Countries'){
  //             if(branches[i][key]){
  //               object['branchCountryId'] = branches[i].Countries.countryName;
  //             }else{
  //               object['branchCountryId'] = "";
  //             }
  //           }
  //           else if(key === 'States'){
  //             if(branches[i][key]){
  //               object['branchStateId'] = branches[i].States.stateName;
  //             }else{
  //               object['branchStateId'] = "";
  //             }
  //           }
  //           else if(key === 'CreatedUser'){
  //             if(branches[i][key]){
  //               object['createdBy'] = branches[i].CreatedUser.name;
  //             }else{
  //               object['createdBy'] = "";
  //             }
  //           }
  //           else if(key === 'UpdatedUser'){
  //             if(branches[i][key]){
  //               object['updatedBy'] = branches[i].UpdatedUser.name;
  //             }else{
  //               object['updatedBy'] = "";
  //             }
  //           }else{
  //             object[key] = branches[i][key];
  //           } 
  //         }
  //         colData.push(object)
  //       }
  //       this.setState({datas:colData});
  //     })
  //     .catch(error => {
  //       console.log('Error fetching and parsing data', error);
  //     });
  // }

  toggleSearch() {
    this.setState({ showSearch: !this.state.showSearch });
  }

  handleChange(event) {
    event.persist();
    this.props.onUserInput(event.target.value);
  }

  render() {
    const {
      numSelected,
      classes,
      filterText,
      placeholder,
      title,
      addNew,
      width,
      anchor,
      branch,
      items
    } = this.props;
    const { 
      showSearch,
      // datas 
    } = this.state;

    const getPrintItems = dataArray => dataArray.map((item, index) => {
      return (
        <Fragment key={index.toString()}>
          <AlertPrint
            item={item}
            key={item.get("id")}
            anchor={anchor}
          />
        </Fragment>
      );
    });

    return (
      <Fragment>
        <Toolbar
          className={classNames(classes.toolbar, {
            [classes.highlight]: numSelected > 0,
          })}
        >
          <div className={classes.title}>
            {numSelected > 0 ? (
              <Typography color="inherit" variant="subtitle1">
                {numSelected} selected
            </Typography>
            ) : (
                <Typography variant="h6">{title}</Typography>
              )}
          </div>
          <div className={classes.spacer} />
          <div className={classes.actionsToolbar}>
            {numSelected > 0 ? (
              <div>
                <Tooltip title="Bookmark">
                  <IconButton aria-label="Bookmark">
                    <BookmarkIcon />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Archive">
                  <IconButton aria-label="Archive">
                    <ArchiveIcon />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Delete">
                  <IconButton aria-label="Delete">
                    <DeleteIcon />
                  </IconButton>
                </Tooltip>
              </div>
            ) : (
                <div className={classes.actions}>
                  {showSearch &&
                    <FormControl className={classNames(classes.textField)}>
                      <Input
                        id="search_filter"
                        type="text"
                        placeholder={placeholder}
                        value={filterText}
                        onChange={(event) => this.handleChange(event)}
                        endAdornment={
                          <InputAdornment position="end">
                            <IconButton aria-label="Search filter">
                              <SearchIcon />
                            </IconButton>
                          </InputAdornment>
                        }
                      />
                    </FormControl>
                  }
                  <Tooltip title="Filter list">
                    <IconButton
                      aria-label="Filter list"
                      className={classes.filterBtn}
                      onClick={() => this.toggleSearch()}
                    >
                      <FilterListIcon />
                    </IconButton>
                  </Tooltip>
                </div>
              )}
          </div>
          <div className={classes.actions}>
            <Tooltip title="Print">
              <IconButton
                aria-label="Print"
                className={classes.buttonClass}
              >
                <ReactToPrint
                  trigger={() => <Print />}
                  content={() => this.componentRef}
                />
              </IconButton>
            </Tooltip>
          </div>
          {/* <div className={classes.actions}>
            <CsvDownloader
              filename="Branches"
              columns={columns}
              datas={datas}
              bom={false}
            >
              <Tooltip title="Download CSV">
                <IconButton
                  aria-label="Filter list"
                  className={classes.buttonClass}
                >
                  <CloudDownload />
                </IconButton>
              </Tooltip>
            </CsvDownloader>
          </div> */}
          <div className={classes.actions}>
            <Tooltip title="Add Branch">
              <Button variant="contained" onClick={() => addNew(anchor, branch)} color="secondary" className={classes.button}>
                <AddIcon className={classNames(isWidthUp('sm', width) && classes.leftIcon, classes.iconSmall)} />
                {isWidthUp('sm', width) && 'Add'}
              </Button>
            </Tooltip>
          </div>
        </Toolbar>

        <div className={classes.rootTable} style={{ display: "none" }}>
          <Table ref={el => (this.componentRef = el)} className={classNames(css.tableCrud, classes.table, classes.stripped)}>
            <TableHead>
              <TableRow>
                {anchor.length !== 0 ? (
                  anchor.map((item, index) => {
                    if (item.print) {
                      return (
                          <TableCell
                            padding="none"
                            key={index.toString()}
                            width={item.width}
                          >
                            {item.label}
                          </TableCell>
                      );
                    }
                  })) : (
                    <div />
                  )}
                </TableRow>
            </TableHead>
            <TableBody>
              {getPrintItems(items)}
            </TableBody>
          </Table>
        </div>
      </Fragment>
    );
  }
}

TableToolbar.propTypes = {
  classes: PropTypes.object.isRequired,
  filterText: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  placeholder: PropTypes.string.isRequired,
  onUserInput: PropTypes.func.isRequired,
  numSelected: PropTypes.number.isRequired,
  addNew: PropTypes.func.isRequired,
  width: PropTypes.string.isRequired,
  anchor: PropTypes.array.isRequired,
  branch: PropTypes.string.isRequired,
  items: PropTypes.object.isRequired,
};

export default withStyles(styles)(TableToolbar);
