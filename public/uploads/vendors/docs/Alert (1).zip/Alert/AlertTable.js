import React , { Fragment } from 'react';
import PropTypes from 'prop-types';
import ReactToPrint from "react-to-print";
import { fromJS } from 'immutable';
import { withStyles } from '@material-ui/core/styles';
import Print from '@material-ui/icons/Print';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableFooter from '@material-ui/core/TableFooter';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import TableRow from '@material-ui/core/TableRow';
import Tooltip from '@material-ui/core/Tooltip';
import classNames from 'classnames';
import withWidth, { isWidthUp } from '@material-ui/core/withWidth';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import AddIcon from '@material-ui/icons/Add';
import DeleteIcon from '@material-ui/icons/Delete';
import ArchiveIcon from '@material-ui/icons/Archive';
import BookmarkIcon from '@material-ui/icons/Bookmark';
import FilterListIcon from '@material-ui/icons/FilterList';
import SearchIcon from '@material-ui/icons/Search';
import Input from '@material-ui/core/Input';
import InputAdornment from '@material-ui/core/InputAdornment';
import Button from '@material-ui/core/Button';
import css from 'dan-styles/Table.scss';
import AlertReadOnly from './AlertReadOnly';
import AlertPrint from './AlertPrint';
import styles from '../../Parts/tableStyle-jss';

class AlertTable extends React.Component {
  constructor(props, context) {
    super(props, context);

    this.state = {
      page: this.props.page,
      rowsPerPage: this.props.rowsPerPage,
      defaultPerPage: this.props.defaultPerPage,
      filterText: this.props.filterText,
      numSelected: this.props.selected,
      order: this.props.order,
      orderBy: this.props.orderBy,
      items: this.props.items,
      inActiveItems: this.props.inActiveItems,
      status: '1',
      active: false,
      showSearch: false,
    };
  }
  
  toggleSearch() {
    this.setState({ showSearch: !this.state.showSearch });
  }

  handleChange(event) {
    event.persist();
    this.handleUserInput(event.target.value);
  }

  handleChangePage = (event, page) => {
    this.setState({ page });
  };

  handleChangeRowsPerPage = event => {
    this.setState({ rowsPerPage: event.target.value });
  };

  handleUserInput(value) {
    if(this.state.active == false){
      const numOfRec = JSON.stringify(this.props.items);
      const countLength = JSON.parse(numOfRec);
      // Show all item first
      if (value !== '') {
        this.setState({ rowsPerPage: countLength.length });
      } else {
        this.setState({ rowsPerPage: this.state.defaultPerPage });
      }
      // Show result base on keyword
      this.setState({ filterText: value.toLowerCase() });
    }else{
      const numOfRec = JSON.stringify(this.props.inActiveItems);
      const countLength = JSON.parse(numOfRec);
      // Show all item first
      if (value !== '') {
        this.setState({ rowsPerPage: countLength.length });
      } else {
        this.setState({ rowsPerPage: this.state.defaultPerPage });
      }
      // Show result base on keyword
      this.setState({ filterText: value.toLowerCase() });
    }
    
  }
  
  createSortHandler = property => event => {
    this.handleRequestSort(event, property);
  };

  handleRequestSort = (event, property) => {
    const orderBy = property;
    let order = 'desc';

    if (this.state.orderBy === property && this.state.order === 'desc') {
      order = 'asc';
    }
    
    if(this.state.active == false){
      const itemsCount = JSON.stringify(this.state.items);
      const count = JSON.parse(itemsCount);
      const counts =
      order === 'desc'
        ? count.sort((a, b) => (b[orderBy] < a[orderBy] ? -1 : 1))
        : count.sort((a, b) => (a[orderBy] < b[orderBy] ? -1 : 1));
      const items = fromJS(counts);
      this.setState({ items, order, orderBy });
    }else{
      const itemsCount = JSON.stringify(this.state.inActiveItems);
      const count = JSON.parse(itemsCount);
      const counts =
      order === 'desc'
        ? count.sort((a, b) => (b[orderBy] < a[orderBy] ? -1 : 1))
        : count.sort((a, b) => (a[orderBy] < b[orderBy] ? -1 : 1));
      const inActiveItems = fromJS(counts);
      this.setState({ inActiveItems, order, orderBy });
    }
  };
  
  handleChangeStatus = event => {
    if(event.target.value == 1){
      this.setState({ status: event.target.value });
      this.setState({ active: false });
    }else{
      this.setState({ status: event.target.value });
      this.setState({ active: true });
    }
  };

  render() {
    const {
      classes,
      removeRow,
      editRow,
      addNew,
      anchor,
      branch,
      width,
      title,
    } = this.props;

    const { 
      rowsPerPage, 
      page, 
      numSelected,
      filterText,
      order,
      orderBy,
      items,
      inActiveItems,
      status,
      active,
      showSearch
    } = this.state;
    
    const itemsCount = JSON.stringify(items);
    const count = JSON.parse(itemsCount);

    const itemsInactiveCount = JSON.stringify(inActiveItems);
    const countInactive = JSON.parse(itemsInactiveCount);

    const getHead = dataArray => dataArray.map((item, index) => {
      if (!item.hidden) {
        if(item.name !== 'action'){
          return (
            <TableCell
              className={classes.sortable}
              padding="none"
              key={index.toString()}
              numeric={item.numeric}
              sortDirection={orderBy === item.name ? order : false}
              width={item.width}
            >
              <Tooltip
                title="Sort"
                placement={item.numeric ? 'bottom-end' : 'bottom-start'}
                enterDelay={300}
              >
                <TableSortLabel
                  active={orderBy === item.name}
                  direction={order}
                  onClick={this.createSortHandler(item.name)}
                >
                  {item.label}
                </TableSortLabel>
              </Tooltip>
            </TableCell>
          );
        }else{
          return (
          <TableCell
              className={classes.sortable}
              padding="none"
              key={index.toString()}
              width={item.width}
            >
            {item.label}
            </TableCell>
          )
        }
      }
        
      return false;
    });

    const getItems = dataArray => dataArray.slice(page * rowsPerPage, 
      (page * rowsPerPage) + rowsPerPage).map((item, index) => {
      if (item.get('alertName').toLowerCase().indexOf(filterText) === -1) {
        return false;
      }
      return (
        <Fragment key={index.toString()}>
          <AlertReadOnly
            item={item}
            removeRow={() => removeRow(item, branch)}
            key={item.get('id')}
            editRow={() => editRow(item, branch)}
            anchor={anchor}
            branch={branch}
            active={active}
          />
        </Fragment>
      );
    });

    const getPrintItems = dataArray => dataArray.map((item, index) => {
      return (
        <Fragment key={index.toString()}>
          <AlertPrint
            item={item}
            key={item.get("id")}
            anchor={anchor}
          />
        </Fragment>
      );
    });
    
    return (
      <div>
        <Toolbar
          className={classNames(classes.toolbar, {
            [classes.highlight]: numSelected.length > 0,
          })}
        >
          <div className={classes.actions}>
            <Tooltip title="Add Alerts">
              <Button variant="contained" onClick={() => addNew(anchor, branch)} color="secondary" className={classes.button} style={{borderRadius:"6px"}} >
                <AddIcon className={classNames(isWidthUp('sm', width) && classes.leftIcon, classes.iconSmall)} />
                {isWidthUp('sm', width) && 'Add'}
              </Button>
            </Tooltip>
          </div>
          
          <div className={classes.actions} style={{marginLeft:"10px"}}>
            <FormControl className={classes.formControl} style={{height: "36px"}}>
              <Select
                value={status}
                onChange={this.handleChangeStatus}
                inputProps={{
                  name: 'status',
                  id: 'status-simple',
                }}
                style={{marginTop:"0px"}}
              >
                <MenuItem value="1">Active</MenuItem>
                <MenuItem value="0">InActive</MenuItem>
              </Select>
            </FormControl>
          </div>

          <div className={classes.title}>
            {numSelected.length > 0 ? (
              <Typography color="inherit" variant="subtitle1">
                {numSelected.length} selected
            </Typography>
            ) : (
                <Typography variant="h6">{title}</Typography>
              )}
          </div>
          
          <div className={classes.spacer} />

          <div className={classes.actionsToolbar}>
            {numSelected.length > 0 ? (
              <div>
                <Tooltip title="Bookmark">
                  <IconButton aria-label="Bookmark">
                    <BookmarkIcon />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Archive">
                  <IconButton aria-label="Archive">
                    <ArchiveIcon />
                  </IconButton>
                </Tooltip>
                <Tooltip title="Delete">
                  <IconButton aria-label="Delete">
                    <DeleteIcon />
                  </IconButton>
                </Tooltip>
              </div>
            ) : (
                <div className={classes.actions}>
                  {showSearch &&
                    <FormControl className={classNames(classes.textField)}>
                      <Input
                        id="search_filter"
                        type="text"
                        placeholder="Search By Name"
                        value={filterText}
                        onChange={(event) => this.handleChange(event)}
                        endAdornment={
                          <InputAdornment position="end">
                            <IconButton aria-label="Search filter">
                              <SearchIcon />
                            </IconButton>
                          </InputAdornment>
                        }
                      />
                    </FormControl>
                  }
                  <Tooltip title="Filter list">
                    <IconButton
                      aria-label="Filter list"
                      className={classes.filterBtn}
                      onClick={() => this.toggleSearch()}
                    >
                      <FilterListIcon />
                    </IconButton>
                  </Tooltip>
                </div>
              )}
          </div>
          <div className={classes.actions}>
            <Tooltip title="Print">
              <IconButton
                aria-label="Print"
                className={classes.buttonClass}
              >
                <ReactToPrint
                  trigger={() => <Print />}
                  content={() => this.componentRef}
                />
              </IconButton>
            </Tooltip>
          </div>
        </Toolbar>

        <div className={classes.rootTable}>
            <Table className={classNames(css.tableCrud, classes.table, classes.stripped)}>
            <TableHead>
              <TableRow>
                { getHead(anchor) }
              </TableRow>
            </TableHead>
            <TableBody>
              {active === false ? (
                <Fragment>
                  {getItems(items)}
                </Fragment>
              ):(
                <Fragment>
                  {getItems(inActiveItems)}
                </Fragment>
              )}   
            </TableBody>
            <TableFooter>
              <TableRow>
              {active === false ? (
                <Fragment>
                  <TablePagination
                  colSpan={5}
                  count={count.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onChangePage={this.handleChangePage}
                  onChangeRowsPerPage={this.handleChangeRowsPerPage}
                />
                </Fragment>
              ):(
                <Fragment>
                  <TablePagination
                  colSpan={5}
                  count={countInactive.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  onChangePage={this.handleChangePage}
                  onChangeRowsPerPage={this.handleChangeRowsPerPage}
                />
                </Fragment>
              )}  
                
              </TableRow>
            </TableFooter>
          </Table>

          <div className={classes.rootTable} style={{ display: "none" }}>
          <Table ref={el => (this.componentRef = el)} className={classNames(css.tableCrud, classes.table, classes.stripped)}>
            <TableHead>
              <TableRow>
                {anchor.length !== 0 ? (
                  anchor.map((item, index) => {
                    if (item.print) {
                      return (
                          <TableCell
                            padding="none"
                            key={index.toString()}
                            width={item.width}
                          >
                            {item.label}
                          </TableCell>
                      );
                    }
                  })) : (
                    <div />
                  )}
                </TableRow>
            </TableHead>
            <TableBody>
              {getPrintItems(items)}
            </TableBody>
          </Table>
        </div>

        </div>
      </div>
    );
  }
}

AlertTable.propTypes = {
  title: PropTypes.string.isRequired,
  classes: PropTypes.object.isRequired,
  anchor: PropTypes.array.isRequired,
  addNew: PropTypes.func.isRequired,
  removeRow: PropTypes.func.isRequired,
  editRow: PropTypes.func.isRequired,
  branch: PropTypes.string.isRequired,
  width: PropTypes.string.isRequired,
  filterText: PropTypes.string.isRequired,
  selected: PropTypes.array.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
  page: PropTypes.number.isRequired,
  defaultPerPage: PropTypes.number.isRequired,
  order: PropTypes.string.isRequired,
  orderBy: PropTypes.string.isRequired,
  items: PropTypes.object.isRequired,
  inActiveItems: PropTypes.object.isRequired,
};

export default withWidth()(withStyles(styles)(AlertTable));
