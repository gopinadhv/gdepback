import React from 'react';
import axios from "axios";
import PropTypes from 'prop-types';
import TableCell from '@material-ui/core/TableCell';
import { withStyles } from '@material-ui/core/styles';
import IconButton from '@material-ui/core/IconButton';
import Tooltip from '@material-ui/core/Tooltip';
import Button from '@material-ui/core/Button';
import classNames from 'classnames';
import css from 'dan-styles/Table.scss';
import DeleteIcon from '@material-ui/icons/Delete';
import EditIcon from '@material-ui/icons/BorderColor';
import  GlobalVariable  from "../../../../path/global";

const baseApiUrl = GlobalVariable.BASE_API_URL;
const styles = theme => ({
  button: {
    margin: theme.spacing.unit,
  },
});

class AlertReadOnly extends React.Component {
  render() {
    const {
      anchor,
      classes,
      item,
      removeRow,
      editRow,
      branch,
      active
    } = this.props;
    const eventDel = () => {
      const userDetails = JSON.parse(localStorage.getItem("userDetails"));
      // console.log(userDetails.token);
      let obj = JSON.stringify(item);
      let bodyParameters = JSON.parse(obj);
      var config = {
          headers: {'Authorization': userDetails.token}
      };
      var object = bodyParameters;
      removeRow(item, branch);
      axios.delete(baseApiUrl + "v1/alert/"+ object.id, config).then(response => {
        console.log(response.data); 
        window.location.href = '/app/alert';
     })
     .catch(error => {
       // console.log(error.response);
       if(error.response.data.success === false){
         alert("Token Expired");
       } 
     });
    };

    const eventActive = () => {
      const userDetails = JSON.parse(localStorage.getItem("userDetails"));
      let obj = JSON.stringify(item);
      let bodyParameters = JSON.parse(obj);
      var config = {
          headers: {'Authorization': userDetails.token}
      };
      var object = bodyParameters;
      removeRow(item, branch);
      axios.get(baseApiUrl + "v1/alertActive/"+ object.id, config).then(response => {
        console.log(response.data);
        window.location.href = '/app/alert';
     })
     .catch(error => {
       if(error.response){
         alert("Token Expired");
       } 
     });
    };

    const eventEdit = () => {
      editRow(item, branch);
    };
    const renderCell = dataArray => dataArray.map((itemCell, index) => {
      if (itemCell.name !== 'action' && !itemCell.hidden) {
        return (
          <TableCell padding="none" key={index.toString()}>
            {item.get(itemCell.name) !== undefined ? item.get(itemCell.name) : ''}
          </TableCell>
        );
      }
      return false;
    });
    return (
      <tr>
        {renderCell(anchor)}
        {active === false ? (
            <TableCell padding="none">
            <Tooltip title="Edit">
              <IconButton
                onClick={() => eventEdit(this)}
                className={classNames((item.edited ? css.hideAction : ''), classes.button)}
                aria-label="Edit"
              >
                <EditIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title="Deactivate">
              <IconButton
                onClick={() => eventDel(this)}
                className={classes.button}
                aria-label="Delete"
              >
                <DeleteIcon />
              </IconButton>
            </Tooltip>
          </TableCell>
          ):(
            <TableCell padding="none">
              <Tooltip title="Activate">
                <Button 
                  variant="contained" 
                  size="small" 
                  color="primary" 
                  className={classes.button}
                  onClick={() => eventActive(this)}
                >
                  Activate
                </Button>
              </Tooltip>
          </TableCell>
          )}
      </tr>
    );
  }
}

AlertReadOnly.propTypes = {
  anchor: PropTypes.array.isRequired,
  classes: PropTypes.object.isRequired,
  item: PropTypes.object.isRequired,
  removeRow: PropTypes.func.isRequired,
  editRow: PropTypes.func.isRequired,
  branch: PropTypes.string.isRequired,
};

export default withStyles(styles)(AlertReadOnly);
