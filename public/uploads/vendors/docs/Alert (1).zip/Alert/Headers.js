const headers = [
    { 
      name: "id", 
      label: "Id", 
      initialValue: "", 
      hidden: true, 
      numeric: false,
      print: false 
    },
    {
			name: 'alertName',
			label: 'Name',
			initialValue: '',
			hidden: false,
			numeric: true,
			print: true
		},
    {
			name: 'alertCode',
			label: 'Code',
			initialValue: '',
			hidden: false,
			numeric: true,
			print: true
		},
		{
			name: 'alertsTo',
			label: 'AlertsTo',
			initialValue: '',
			hidden: false,
			numeric: true,
			print: false
		},
		{
			name: 'description',
			label: 'Description',
			initialValue: '',
			hidden: true,
			numeric: true,
			print: false
		},
    
    { 
      name: "action", 
      label: "Actions", 
      initialValue: "", 
      hidden: false,
      numeric: false,
      print: false 
    }
  ];
  
  export default headers;
  