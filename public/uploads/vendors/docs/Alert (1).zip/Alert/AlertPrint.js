import React from 'react';
import PropTypes from 'prop-types';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
  button: {
    margin: theme.spacing.unit,
  },
});

class AlertPrint extends React.Component {
  render() {
    const {
      anchor,
      item,
    } = this.props;
    
    
    const renderCell = dataArray => dataArray.map((itemCell, index) => {
      if (itemCell.print) {
        return (
          <TableCell padding="none" key={index.toString()}>
            {item.get(itemCell.name) !== undefined ? item.get(itemCell.name) : ''}
          </TableCell>
        );
      }
      return false;
    });
    return (
      <TableRow>
          {renderCell(anchor)} 
      </TableRow>    
    );
  }
}

AlertPrint.propTypes = {
  anchor: PropTypes.array.isRequired,
  item: PropTypes.object.isRequired,
};

export default withStyles(styles)(AlertPrint);
