import React from "react";
import PropTypes from "prop-types";
import axios from "axios";
import { fromJS } from 'immutable';
import Form from "../../Parts/Form";
import MainTableForm from "./AlertTable";
import FloatingPanel from "../../Panel/FloatingPanel";
import GlobalVariable from "../../../../path/global";

const baseApiUrl = GlobalVariable.BASE_API_URL;
class AlertCrud extends React.Component {
  componentDidMount() {
    this.props.fetchData(this.props.dataInit, this.props.branch);
    this.props.fetchInactiveData(this.props.InactiveRows, this.props.branch);
  }

  sendValues = values => {
    // console.log(values);
    setTimeout(() => {
      const userDetails = JSON.parse(localStorage.getItem("userDetails"));
      let obj = JSON.stringify(values);
      let bodyParameters = JSON.parse(obj);
      var config = {
        headers: { Authorization: userDetails.token }
      };
      var object = bodyParameters;
      // console.log(object);

      if (object.id === undefined) {
        axios
          .post(baseApiUrl + "v1/alert", object, config)
          .then(response => {
            window.location.href = '/app/alert';
            this.props.submit(fromJS(response.data), this.props.branch);
          })
          .catch(error => {
            if(error.response){
              alert("Token Expired");
            } 
          });
      }
    }, 500);
  };

  render() {
    const {
      title,
      dataTable,
      dataInActiveTable,
      openForm,
      closeForm,
      removeRow,
      addNew,
      editRow,
      anchor,
      children,
      branch,
      initValues,
      selected,
      filterText,
      rowsPerPage,
      page,
      defaultPerPage,
      order,
      orderBy,
      formTitle
    } = this.props;
    return (
      <div>
        <FloatingPanel
          openForm={openForm}
          branch={branch}
          closeForm={closeForm}
          formTitle={formTitle} tableName="Alert"
        >
          <Form
            onSubmit={this.sendValues}
            initValues={initValues}
            branch={branch}
          >
            {children}
          </Form>
        </FloatingPanel>
        <MainTableForm
          title={title}
          addNew={addNew}
          items={dataTable}
          inActiveItems={dataInActiveTable}
          removeRow={removeRow}
          editRow={editRow}
          anchor={anchor}
          branch={branch}
          selected={selected}
          filterText={filterText}
          rowsPerPage={rowsPerPage}
          page={page}
          defaultPerPage={defaultPerPage}
          order={order}
          orderBy={orderBy}
        />
      </div>
    );
  }
}

AlertCrud.propTypes = {
  title: PropTypes.string.isRequired,
  anchor: PropTypes.array.isRequired,
  dataInit: PropTypes.array.isRequired,
  InactiveRows: PropTypes.array.isRequired,
  dataTable: PropTypes.object.isRequired,
  dataInActiveTable: PropTypes.object.isRequired,
  fetchData: PropTypes.func.isRequired,
  fetchInactiveData: PropTypes.func.isRequired,
  submit: PropTypes.func.isRequired,
  addNew: PropTypes.func.isRequired,
  openForm: PropTypes.bool.isRequired,
  closeForm: PropTypes.func.isRequired,
  removeRow: PropTypes.func.isRequired,
  editRow: PropTypes.func.isRequired,
  children: PropTypes.node.isRequired,
  initValues: PropTypes.object.isRequired,
  branch: PropTypes.string.isRequired,
  filterText: PropTypes.string.isRequired,
  selected: PropTypes.array.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
  page: PropTypes.number.isRequired,
  defaultPerPage: PropTypes.number.isRequired,
  order: PropTypes.string.isRequired,
  orderBy: PropTypes.string.isRequired,
  formTitle: PropTypes.string.isRequired,
};

export default AlertCrud;
